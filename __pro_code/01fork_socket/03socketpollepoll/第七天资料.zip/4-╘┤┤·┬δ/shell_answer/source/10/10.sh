#! /bin/bash

join employee.txt bonus.txt | sort -k 2
