/*************************************************************************
	> File Name: math.c
	> Author: 
	> Mail: 
	> Created Time: 2017年04月07日 星期五 00时42分13秒
 ************************************************************************/

#include<stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    double c = 0;
    c = pow(2.0, 3.0);
    printf("c = %lf\n", c);
    return 0;
}
