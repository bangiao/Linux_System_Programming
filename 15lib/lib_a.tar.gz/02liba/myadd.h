extern int myadd(int a, int b);
